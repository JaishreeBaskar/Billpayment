import React, {Component} from 'react';
import Todo from './Todo';

class Todos extends Component {

    state = {
        items : [
            {id:1,title:'First', completed: true},
            {id:2,title:'Second', completed: false},
            {id:3,title:'Third', completed: true}
        ],
        count: 0
    }
    
    constructor(props){
        console.log('Constructor called');
        super(props);
    }

    static getDerivedStateFromProps(props, state) {
        console.log('getDerivedStateFromProps called');
        return state;
    }

    incrementCountHandler = () => {
        //this.state.count = this.state.count + 1;
        // this.setState({count: this.state.count + 1});
        this.setState((prevState)=>{
            return {count: prevState.count + 1}
        });
    }

    removeItemHandler = (id) => {
        const items = [...this.state.items];
        const otherItems = items.filter(i=>i.id !== id);
        this.setState({items: otherItems});
    }

    render() {
        console.log('render called');
        
        const todoItems = this.state.items.map(item => {
            return <Todo key={item.id} title={item.title} removeItem={()=>this.removeItemHandler(item.id)}/>
        });
        return (<div>
            Count: {this.state.count}<br/>
            <button onClick={this.incrementCountHandler}>Increment</button>
            {todoItems}
        </div>);
    }

    componentDidMount = () => {
        console.log('componentDidMount called');
    }

    shouldComponentUpdate = (nextProps, nextState) => {
        console.log('shouldComponentUpdate called');
        return true;
    }

    getSnapshotBeforeUpdate = (prevProps, prevState) => {
        console.log('getSnapshotBeforeUpdate called');
        return {message: 'Test'};
    }

    componentDidUpdate = () => {
        console.log('componentDidUpdate called');
    }
}

export default Todos;
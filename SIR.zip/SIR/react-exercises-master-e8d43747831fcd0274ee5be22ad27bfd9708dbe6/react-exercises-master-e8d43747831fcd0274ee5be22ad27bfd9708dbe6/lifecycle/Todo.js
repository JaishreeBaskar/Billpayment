import React from 'react';

const Todo = (props) => {
    return (<div>
        <h5>{props.title}</h5>
        <div><button>Done</button></div>
        <button onClick={props.removeItem}>Remove</button>
    </div>);
}

export default Todo;
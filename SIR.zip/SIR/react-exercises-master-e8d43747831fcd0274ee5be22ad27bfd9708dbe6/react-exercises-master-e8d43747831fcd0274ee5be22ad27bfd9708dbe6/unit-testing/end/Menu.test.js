import React from 'react';
import {configure, shallow} from 'enzyme';
import Adapter from 'enzyme-adapter-react-16';
import Menu from './Menu';
import MenuItem from './MenuItem';

configure({adapter: new Adapter()});

describe('<Menu/> display', () => {
    let wrapper;
    beforeEach(()=>{
        wrapper = shallow(<Menu/>);
    });

    it('should display 3 items for not authenticated', () => {
       expect(wrapper.find(MenuItem)).toHaveLength(3);
    });

    it('should display 2 items for authenticated', () => {
        wrapper.setProps({authenticated:true});
        expect(wrapper.find(MenuItem)).toHaveLength(2);
    });
});

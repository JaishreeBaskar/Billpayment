import React from 'react';
import TodoAdd from './TodoAdd';
import TodoList from './TodoList';
import Menu from './Menu';

class Todos extends React.Component {
    render(){
        return <div>
            <Menu authenticated={false}></Menu>
            <TodoAdd></TodoAdd>
            <TodoList></TodoList>
        </div>
    }
}
export default Todos;
import React from 'react';

const MenuItem = (props) => {
    return <span className="menu-item"><a href={props.path}>{props.children}</a></span>
}

export default MenuItem;
import React from 'react';
import {configure, shallow} from 'enzyme';
import Adapter from 'enzyme-adapter-react-16';
import {TodoList} from './TodoList';
import TodoItem from './TodoItem';
import ActionItems from './ActionItems';

configure({adapter: new Adapter()});

describe('<TodoList/> display', () => {
    let wrapper;
    beforeEach(()=>{
        wrapper = shallow(<TodoList items={[{}]}/>);
        //items above is required to be set while mounting component
    });

    it('should display items populated', () => {
         expect(wrapper.find(TodoItem)).toHaveLength(1);
     });

     it('should display actions for special category', () => {
        wrapper.setProps({spl:true});
         expect(wrapper.find(ActionItems)).toHaveLength(1);
     });

     it('should not display actions for not special category', () => {
         expect(wrapper.find(ActionItems)).toHaveLength(0);
     });
});

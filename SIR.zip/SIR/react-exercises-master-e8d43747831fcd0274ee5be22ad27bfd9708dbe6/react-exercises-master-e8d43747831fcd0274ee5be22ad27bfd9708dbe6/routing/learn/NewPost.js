import React, {useState} from 'react';
import './NewPost.css';

const NewPost = (props) => {

    const [state, setstate] = useState({title:'', body: ''});

    return <div className='NewPost'>
        <p>
            <input type='text' 
                placeholder='Enter Title here'
                value={state.title} 
                onChange={(e)=>{setstate({title:e.target.value, body:state.body})}}></input>
        </p>
        <p>
            <textarea 
                placeholder='Enter Body here'
                onChange={(e)=>{setstate({title:state.title, body:e.target.value})}}
                value={state.body}>
                </textarea>
        </p>
        <button onClick={()=>{alert('Add: ' + state.title + ' >> ' + state.body);}}>Add</button>
    </div>
}

export default NewPost;
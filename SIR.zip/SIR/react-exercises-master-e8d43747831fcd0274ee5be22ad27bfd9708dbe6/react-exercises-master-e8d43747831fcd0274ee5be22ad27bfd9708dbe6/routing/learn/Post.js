import React from 'react';
import './Post.css';

const Post = (props) => {
    return <div className='Post'>
        <h3>{props.post.title}</h3>
        </div>
}

export default Post;
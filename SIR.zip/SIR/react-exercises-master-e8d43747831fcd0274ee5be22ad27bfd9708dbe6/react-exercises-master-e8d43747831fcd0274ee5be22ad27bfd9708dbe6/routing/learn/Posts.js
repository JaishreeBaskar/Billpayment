import React from 'react';
import axios from 'axios';
import Post from './Post';

export default class Posts extends React.Component {

    constructor(props) {
        super(props);
        this.state = {
            posts: []
        }
    }

    componentDidMount() {
        axios.get('https://jsonplaceholder.typicode.com/posts')
        .then(res => {
            const posts = res.data.slice(0,4);
            this.setState({posts});
        });
    }

    render () {
        return <div>
            {
                this.state.posts.map(post => {
                    return <div key={post.id}><Post post={post}/></div>
                })
            }
        </div>
    }
}
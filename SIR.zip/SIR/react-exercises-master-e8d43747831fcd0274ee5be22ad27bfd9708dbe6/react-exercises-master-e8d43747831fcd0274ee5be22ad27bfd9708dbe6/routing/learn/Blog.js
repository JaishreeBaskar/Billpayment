import React from 'react';
import Posts from './Posts';
import FullPost from './FullPost';
import NewPost from './NewPost';
import './Blog.css';

export default class Blog extends React.Component {

    render () {
        return <div>
            <header>
                <ul>
                    <li><a href="/">Home</a></li>
                    <li><a href="/new-post">New Post</a></li>
                </ul>
            </header>
            <section>
                <div style={{clear:'both'}}>
                    <Posts/>
                    <FullPost postId="1"/>
                    <NewPost/>
                </div>
            </section>
        </div>
    }

}
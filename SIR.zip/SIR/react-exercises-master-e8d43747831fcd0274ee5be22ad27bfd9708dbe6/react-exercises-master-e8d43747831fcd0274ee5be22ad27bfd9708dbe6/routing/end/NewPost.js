import React, {useState, useEffect} from 'react';
import './NewPost.css';
import { Redirect } from 'react-router';

const NewPost = (props) => {

    const [state, setstate] = useState({title:'', body: ''});

    const [submitted, setSubmitted] = useState(false);

    const addPostHandler = () => {
        console.log('Submitting '+state.title+' >> '+state.body);
        setTimeout(() => {
            setSubmitted(true);        
        }, 1000);
    }

    return <div className='NewPost'>
        {submitted ? <Redirect to='/'/> : null}
        <p>
            <input type='text' 
                placeholder='Enter Title here'
                value={state.title} 
                onChange={(e)=>{setstate({title:e.target.value, body:state.body})}}></input>
        </p>
        <p>
            <textarea 
                placeholder='Enter Body here'
                onChange={(e)=>{setstate({title:state.title, body:e.target.value})}}
                value={state.body}>
                </textarea>
        </p>
        <button onClick={addPostHandler}>Add</button>
    </div>
}

export default NewPost;
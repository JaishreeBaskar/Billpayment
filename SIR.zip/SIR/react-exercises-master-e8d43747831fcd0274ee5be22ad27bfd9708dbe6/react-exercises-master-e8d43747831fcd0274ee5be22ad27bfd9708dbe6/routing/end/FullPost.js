import React, {useEffect, useState} from 'react';
import axios from 'axios';
import './FullPost.css';

const FullPost = (props) => {

    const [post, setPost] = useState({title:'', body: ''});
    
    useEffect(() => {
        loadData(props.match.params.id);
    }, []);

    useEffect(()=>{
        loadData(props.match.params.id);
    }, [props.match.params.id]);

    const loadData = (id) => {
        axios.get('https://jsonplaceholder.typicode.com/posts/' + id)
        .then(res => {  
            setPost({title:res.data.title, body:res.data.body});
        })
    } 

    return <div className='FullPost'>
        <h3>{post.title}</h3>
        <p>{post.body}</p>
    </div>
}

export default FullPost;
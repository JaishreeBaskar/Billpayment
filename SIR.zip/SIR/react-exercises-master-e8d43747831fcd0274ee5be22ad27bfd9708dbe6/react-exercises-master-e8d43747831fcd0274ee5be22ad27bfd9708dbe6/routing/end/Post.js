import React from 'react';
import './Post.css';
import { withRouter } from 'react-router';

const Post = (props) => {
    return <div className='Post' onClick={props.clicked}>
        <h3>{props.post.title}</h3>
        </div>
}

export default withRouter(Post);
import React from 'react';
import './Blog.css';
import { Route, Switch } from 'react-router';
import Posts from './Posts';
import NewPost from './NewPost';
import FullPost from './FullPost';
import { NavLink } from 'react-router-dom';

export default class Blog extends React.Component {

    render () {
        return <div>
            <header>
                <ul>
                    <li><NavLink to="/" exact>Home</NavLink></li>
                    <li><NavLink to={{
                        pathname: '/new-post'
                    }}>New Post</NavLink></li>
                </ul>
            </header>
            <section>
                <div style={{clear:'both'}}>
                    <Switch>
                        <Route path="/new-post" component={NewPost}/>     
                        <Route path="/" component={Posts}/> 
                    </Switch>
                </div>
            </section>
        </div>
    }

}
import React from 'react';

const Cart = (props) => {

    let totalPrice = 0;

    props.items.forEach(item => {
        totalPrice += item.price;
    });

    return <div>
        {
            props.items.map(item => {
               return ( 
               <div>
                   <h3>{item.title}</h3>
                   <p>{item.price}</p>
               </div>);
            })
        }
        <p>Total Price: {totalPrice}</p>
    </div>
}

export default Cart; 
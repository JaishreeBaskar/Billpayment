import React, {useState} from 'react';
import Cart from './Cart';

const Catalog = (props) => {

    const [currState, setState] = useState({
        products: [
            {
                id: 1,
                title: 'Watch',
                price: 200
            },
            {
                id: 2,
                title: 'Door',
                price: 100
            }
        ],
        items: []
    });

    const addToCartHandler = (id) => {
        const cartItems = [...currState.items];
        currState.products.forEach(product => {
            if(product.id === id) {
                cartItems.push(product);
            }
        })
        setState({products:currState.products, items:cartItems});
    }

    const products = currState.products.map( prod => {
        return <div>
            <h2>{prod.title}</h2>
            <p>{prod.price}</p>
            <button onClick={()=>addToCartHandler(prod.id)}>Add to Cart</button>
        </div>
    });

    return (
        <div>
            <h1>Products</h1>
            {products}
            <h1>Cart</h1>
            <Cart items={currState.items} />
        </div>
    );
}

export default Catalog;
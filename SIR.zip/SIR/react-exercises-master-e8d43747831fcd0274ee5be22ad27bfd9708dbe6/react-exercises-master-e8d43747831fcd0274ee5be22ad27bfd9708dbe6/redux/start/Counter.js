import React, { Component } from 'react';
import CounterControl from './CounterControl/CounterControl';
import CounterOutput from './CounterOutput/CounterOutput';

class Counter extends Component {

    render () {
        return (
            <div>
                <CounterOutput value='0' />
                <CounterControl label="Increment"/>
                <CounterControl label="Decrement"/>
                <CounterControl label="Add 5"/>
                <CounterControl label="Subtract 5"/>
                <hr/>
                <button>Store Result</button>
            </div>
        );
    }
}

export default Counter;
import React from 'react';

const NormalComponent = () => {
    return <div style={{width:'300px',height:'100px',backgroundColor:'#9fa', margin:'20px', padding: '30px'}}>Normal Component</div>
}

export default NormalComponent;
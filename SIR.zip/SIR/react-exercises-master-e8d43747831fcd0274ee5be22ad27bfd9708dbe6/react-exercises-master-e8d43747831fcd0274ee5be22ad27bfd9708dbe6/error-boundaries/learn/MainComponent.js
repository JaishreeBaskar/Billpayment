import React, {Component} from 'react';
import NormalComponent from './NormalComponent';
import VulnerableComponent from './VulnerableComponent';
import ErrorBoundary from './ErrorBoundary';

export default class MainComponent extends Component {

    render() {
        return <div>
            <NormalComponent></NormalComponent>
            <ErrorBoundary>
                <VulnerableComponent></VulnerableComponent>
            </ErrorBoundary>
        </div>
    }
}
import React, {Component} from 'react';
import NormalComponent from './NormalComponent';
import VulnerableComponent from './VulnerableComponent';

export default class MainComponent extends Component {

    render() {
        return <div>
            <NormalComponent></NormalComponent>
            <VulnerableComponent></VulnerableComponent>
        </div>
    }
}